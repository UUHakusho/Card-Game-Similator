package question2;

import java.util.Scanner;

public class StrategyFactory {

    Scanner sc = new Scanner(System.in);

    public StrategyFactory() {

    }

    public Strategy chooseStrategy(){
        int choice = 0;
        System.out.println("Welcome to Strategy Factory, choose which strategy you want");
        System.out.println("default is BasicStrategy, 1 is Human Strategy");
        choice = sc.nextInt();

        switch (choice){
            default:
                return new BasicStrategy();
            case 1:
                return new HumanStrategy();
        }
    }
}

