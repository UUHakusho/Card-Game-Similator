package question2;

import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class HumanStrategy implements Strategy {

    Scanner sc = new Scanner(System.in);
    @Override
    public boolean cheat(Bid b, Hand h) {
        boolean willCheat = false;
        Card.Rank priorRank = b.getRank();

        Card.Rank nextRank  = priorRank.getNext();

        if (!h.getCount().containsKey(nextRank) && (!h.getCount().containsKey(priorRank))){
            willCheat = true;
        }

        return willCheat;
    }

    @Override
    public Bid chooseBid(Bid b, Hand h, boolean cheat) {
        Random rand = new Random();
        Card.Rank bidRank = b.getRank(); //initialising it as same rank as the previous bid's rank
        Hand bidHand = new Hand(); //initialised as an empty hand
        System.out.println(h);
        int amountOfBidRank = h.countRank(bidRank);
        int amountOfNext = h.countRank(bidRank.getNext());
        Iterator<Card> it = h.iterator();

        if (amountOfBidRank < amountOfNext){
            while (it.hasNext()){

                bidRank = bidRank.getNext();
                Card card = it.next();
                if (card.getRank() == bidRank) {
                    System.out.println("Do you want to play your cards or cheat? enter play or cheat");
                    String answer = sc.nextLine();
                    if (answer == "play") {
                        bidHand.addCard(card);
                        it.remove();
                        System.out.println("card added is--- " + card);
                    }
                    else {
                        cheat = true;
                    }
                }

            }}
        else  {
            if (amountOfBidRank == 0){
                System.out.println("You must cheat right now player");
                cheat = true;
            }
            else {
                while(it.hasNext()) {
                    Card card = it.next();
                    if (card.getRank() == bidRank) {
                        System.out.println("You can play the lowest rank possible, enter play or cheat");
                        String answer2 = sc.nextLine();
                        if (answer2 == "play") {
                            bidHand.addCard(card);
                            it.remove();
                            h.removeCard(card);
                            System.out.println("card added is--- " + card);
                        }
                        else { cheat = true; }
                    }
                }
            }
        }


        //if you decide to cheat, play a single card randomly
        if (cheat){
            int index = rand.nextInt(h.getHand().size());
            Card randomCard = h.getHand().get(index);
            bidHand.getHand().add(randomCard); //plays a randomly generated card in a new hand
            h.removeCard(randomCard);
            bidRank = bidRank.getNext(); //if cheating say next card
            System.out.println("(This is a CHEAT) " + randomCard);
            return new Bid(bidHand, bidRank);
        }

        return new Bid(bidHand, bidRank);

    }

    @Override
    public boolean callCheat(Hand h, Bid b) {
        int total = 0;

        for (Card c : h){
            if (c.getRank().equals(b.getRank())){
                total++;
            }

        }
        if (total > 4) {
            System.out.println("You have all 4 cards of the current bid, they are cheating! Call it? yes or no");
            String answer = sc.nextLine();
            if (answer == "yes"){
                return true;
            }
        }
        return false;
    }
}
